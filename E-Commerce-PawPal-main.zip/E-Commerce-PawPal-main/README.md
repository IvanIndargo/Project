## PawPal (Pet E-Commerce)

PawPal is an e-commerce website that sells pet supplies, such as food, toys, and treats for dogs and cats. Inside the website, there are several features such as login and register, shop products, view product details, wishlist, cart, about us, contact us, and profile. PawPal also have a separate page for the business admins to edit product details, add products, edit stock amounts, and view financial reports and customer purchasing activities.

Notes: 
Before running the application, dont forget to navigate to your project folder and open the terminal. Run `composer install` and `php artisan serve` to start the development server. 
